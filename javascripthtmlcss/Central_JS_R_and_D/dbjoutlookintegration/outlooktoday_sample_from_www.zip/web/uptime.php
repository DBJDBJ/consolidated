<?  
function TIME_uptime($syntax,$lang) {  
	$time['day']      ='day';
	$time['days']     ='days';
	$time['hour']     ="hour";
	$time['hours']    ='hours';
	$time['minute']   ="minute";
	$time['minutes']  ='minutes';
	$time['second']   ="second";
	$time['seconds']  ='seconds';
	$time['week']     ='week';
	$time['weeks']    ='weeks';
    
	$sys_ticks  = filemtime('C:\pagefile.sys');
	$now = time();
	$booted = $now - $sys_ticks;

	$sec_tot    = floor($booted);
	$min_tot    = floor($sec_tot / 60);
	$uur_tot    = floor($min_tot / 60);  
	$dagen_tot  = floor($uur_tot / 24);  
	$weeks      = floor($dagen_tot / 7);  
	$days       = floor($dagen_tot - ($weeks * 7));  
	$hours      = floor($uur_tot - ($dagen_tot * 24));  
	$minutes    = floor($min_tot - ($uur_tot * 60));
	$seconds    = floor($sec_tot - ($min_tot * 60));	
	
	if($days == 1){
		$days = $days ." ".$time['day'];
	}elseif($days == 0){
		$days="";
	}else{
		$days = $days ." ".$time['days'];
	}
	if($weeks == 1){
		$weeks = $weeks ." ".$time['week'];
	}elseif($weeks== 0){
		$weeks="";
	}else{
		$weeks = $weeks ." ".$time['weeks'];
	}
	if($hours == 1){
		$hours = $hours ." ".$time['hour'];
	}else{ $hours = $hours ." ".$time['hours'];
	}
	if($minutes == 1){
		$minutes = $minutes ." ".$time['minute'];
	}else{ $minutes = $minutes ." ".$time['minutes'];
	}
	if($seconds == 1){
		$seconds = $seconds ." ".$time['second'];
	}else{ $seconds = $seconds ." ".$time['seconds'];
	}
	$syntax = "".$weeks." ".$days." ".$hours." ".$minutes." ".$seconds;
    return $syntax;  
}  
print "document.write(\"" . TIME_uptime("","") . "\");";
?>