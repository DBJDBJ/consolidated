﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

using Microsoft.Office.Core;
using Microsoft.Office.Interop.Outlook;

namespace GuidAddin
{
    public partial class GuidFinderAddIn
    {
        private CommandBar menuBar;
        private CommandBarPopup newMenuBar;
        private CommandBarButton getGuidButton;
        private string menuTag = "GuidFinderAddIn";

        #region Add menu item
        private void AddMenuBar()
        {
            try
            {
                // Get the current menu bar.
                this.menuBar = this.Application.ActiveExplorer().CommandBars.ActiveMenuBar;

                // Add a new item to the menu bar.
                this.newMenuBar = (CommandBarPopup)menuBar.Controls.Add(
                                   MsoControlType.msoControlPopup, missing,
                                   missing, missing, false);

                // Add the menu bar if it doesn't exist.
                if (this.newMenuBar != null)
                {
                    this.newMenuBar.Caption = "GuidFinder";
                    this.newMenuBar.Tag = this.menuTag;

                    // Add a new menu item to the menu.
                    this.getGuidButton = (CommandBarButton)newMenuBar.Controls.Add(
                                          MsoControlType.msoControlButton, missing,
                                          missing, 1, true);

                    // Layout the menu item.
                    this.getGuidButton.Style = MsoButtonStyle.msoButtonIconAndCaption;
                    this.getGuidButton.Caption = "Get GUID";
                    this.getGuidButton.FaceId = 25; // Looking Glass icon
                    //this.getGuidButton.Tag = "c123";
                    this.getGuidButton.Click += new _CommandBarButtonEvents_ClickEventHandler(this.getGuid_Click);

                    // Make our result visible.
                    this.newMenuBar.Visible = true;
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message.ToString(), "Error Message Box", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Remove Menu item
        private void RemoveMenubar()
        {
            // If the menu already exists, remove it.
            try
            {
                CommandBarPopup foundMenu = (CommandBarPopup)
                    this.Application.ActiveExplorer().CommandBars.ActiveMenuBar.
                    FindControl(MsoControlType.msoControlPopup,
                    missing, menuTag, true, true);

                if (foundMenu != null)
                {
                    foundMenu.Delete(true);
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        #region Display the Guid
        private void getGuid_Click(CommandBarButton ctrl, ref bool cancel)
        {
            try
            {
                // Get the selected item in Outlook and determine its type.
                Selection outlookSelection = this.Application.ActiveExplorer().Selection;

                if (outlookSelection.Count > 0)
                {
                    string itemGuid = string.Empty;
                    object selectedItem = outlookSelection[1];

                    if (selectedItem is MailItem)
                    {
                        MailItem mailItem = (selectedItem as MailItem);
                        itemGuid = mailItem.EntryID;
                    }
                    else if (selectedItem is ContactItem)
                    {
                        ContactItem contactItem = (selectedItem as ContactItem);
                        itemGuid = contactItem.EntryID;
                    }
                    else if (selectedItem is AppointmentItem)
                    {
                        AppointmentItem apptItem = (selectedItem as AppointmentItem);
                        itemGuid = apptItem.EntryID;
                    }
                    else if (selectedItem is TaskItem)
                    {
                        TaskItem taskItem = (selectedItem as TaskItem);
                        itemGuid = taskItem.EntryID;
                    }
                    else if (selectedItem is MeetingItem)
                    {
                        MeetingItem meetingItem = (selectedItem as MeetingItem);
                        itemGuid = meetingItem.EntryID;
                    }

                    if (itemGuid != String.Empty)
                    {
                        MessageBox.Show(String.Format("The GUID of this item is {0}", itemGuid), "Guid", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("The item type could not be determined.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }

            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            this.RemoveMenubar();
            this.AddMenuBar();
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }

        #endregion
    }
}
